# Lounge All Bot
_**Bu bot, gruplarda 10.000'e kadar üyeden bahsedebilir ve kanallarda 200'e kadar üyeden bahsedebilir. !**_

### 🏷 Bilgi
- Dil: Python.
- Telgraf Kütüphanesi: Telethon.
- yakında javascript surumu gelcektir

### 🚀 Deploy to heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Drmehmetaktass/tag)

### 🎯 Krediler ve Diğer YILDIZ VERMEYİ UNUTMA
- [teşekkür](https://github.com/bodrumlubebek) TEŞEKKÜR ;)
- [BEN](https://github.com/drmehmetaktass) BU PROJE İÇİN
**Beni Github'dan takip etmeyi unutmayın ✌️**
